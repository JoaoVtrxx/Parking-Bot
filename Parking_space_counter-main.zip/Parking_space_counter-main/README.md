# Parking space counter created using OpenCV and Python

![parking_space_counter](https://user-images.githubusercontent.com/72137556/164909493-ad13efb6-6997-41de-bc1c-168c11b2532b.png)

## Result:
https://youtu.be/LERHWFmSSdM

## Video used in the code:
Tom Berrigan
https://www.youtube.com/watch?v=yojapmOkIfg&list=LL&index=10

Download this video in 1080p, rename it to parking.mp4 and place it in an input folder, and you are good to run the parking_space_counter.py.


## The code is inspired by: 
Murtaza's Workshop - Robotics and AI
https://www.youtube.com/watch?v=caKnQlCMIYI
